package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.Editable;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class change_password extends AppCompatActivity {

    EditText curr, newPass, newCurrPass;
    Button confirm;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_change_password);
        curr = findViewById(R.id.currentPassword);
        newPass = findViewById(R.id.newPassword);
        newCurrPass = findViewById(R.id.confirmPassword);
        confirm = findViewById(R.id.confirm);


        confirm.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String s1 = curr.getText().toString();
                String s2 = newPass.getText().toString();
                String s3 = newCurrPass.getText().toString();

                if(!s2.equals(s3)){
                    Toast.makeText(change_password.this, "Password mismatch!!", Toast.LENGTH_SHORT).show();
                    return;
                }
                DBHelper helper = new DBHelper(getApplicationContext());

                SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
                String email = sh.getString("email", "");

                if(helper.checkPassword(email, s1)){
                    helper.updatePassword(email, s3);
                }
                else{
                    Toast.makeText(change_password.this, "Invalid current password", Toast.LENGTH_SHORT).show();
                }

            }
        });

    }
}