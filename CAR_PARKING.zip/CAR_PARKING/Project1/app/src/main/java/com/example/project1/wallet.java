package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.view.View;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class wallet extends AppCompatActivity {
    Button btn;
    TextView amount_field;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_wallet);

        SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
        int amt = sh.getInt("amount", 0);


        btn = findViewById(R.id.addMoney);
        amount_field = findViewById(R.id.textView3);

        amount_field.setText("Wallet Balance Rs " + amt);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),CreditCard.class);
                startActivity(i);
            }
        });

    }
}