package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;


import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

public class login extends AppCompatActivity {
    TextView rgstr,email,password;
    Button guest,login;
    DBHelper db;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = findViewById(R.id.editTextTextPersonName3);
        password = findViewById(R.id.editTextTextPersonName4);
        rgstr = (TextView) findViewById(R.id.tv);

        login = (Button) findViewById(R.id.login);
        db = new DBHelper(this);

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String useremail = email.getText().toString();
                String pass = password.getText().toString();
                if(useremail.equals("")||pass.equals(""))
                {
                    Toast.makeText(login.this, "please insert all the fields", Toast.LENGTH_SHORT).show();
                }
                else{
                    Boolean checkuserpass = db.checkusernamepassword(useremail,pass);
                    if(checkuserpass == true){
                        Toast.makeText(login.this, "successfully logged in", Toast.LENGTH_SHORT).show();

                        SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
                        SharedPreferences.Editor myEdit = sh.edit();

                        myEdit.putString("email", useremail);
                        myEdit.putString("password", pass);
                        myEdit.apply();

                        Intent intent = new Intent(login.this,MainActivity.class);
                        startActivity(intent);
                    }
                    else{
                        Toast.makeText(login.this, "invalid credentials", Toast.LENGTH_SHORT).show();
                    }
                }
            }
        });
    }
    public void btnNext2(View view){
        Intent intent = new Intent(this,Register.class);
        startActivity(intent);
    }

}
