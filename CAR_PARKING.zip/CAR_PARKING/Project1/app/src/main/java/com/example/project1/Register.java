package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;
import android.content.Intent;

public class Register extends AppCompatActivity {
    EditText name,email,password,cpassword,phone;
    Button register,login;
    DBHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);
        name = findViewById(R.id.editTextTextPersonName13);
        email = findViewById(R.id.editTextTextPersonName15);
        password = findViewById(R.id.editTextTextPersonName16);
        cpassword = findViewById(R.id.editTextTextPersonName17);
        phone = findViewById(R.id.editTextTextPersonName18);
        register = findViewById(R.id.button6);
        login = findViewById(R.id.button);
        db= new DBHelper(this);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String username = name.getText().toString();
                String useremail = email.getText().toString();
                String pass=password.getText().toString();
                String cpass = cpassword.getText().toString();
                String userphone = phone.getText().toString();

                if(useremail.equals("")||pass.equals("")||cpass.equals(""))
                    Toast.makeText(Register.this, "please enter all the fields", Toast.LENGTH_LONG).show();
                else {
                    if (pass.equals(cpass)) {
                        Boolean checkuser = db.checkusername(useremail);
                        if (checkuser == false) {
                            Boolean insert = db.insertData(username, useremail, pass, userphone);
                            if (insert == true) {
                                Toast.makeText(Register.this, "Registered Successfully", Toast.LENGTH_LONG).show();
                                Intent intent = new Intent(getApplicationContext(), MainActivity.class);
                                startActivity(intent);
                            } else {
                                Toast.makeText(Register.this, "Registration Fails", Toast.LENGTH_LONG).show();
                            }
                        } else {
                            Toast.makeText(Register.this, "User Already exists", Toast.LENGTH_LONG).show();
                        }
                    }
                }
            }
        });
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(getApplicationContext(),login.class);
                startActivity(intent);
            }
        });
    }
}