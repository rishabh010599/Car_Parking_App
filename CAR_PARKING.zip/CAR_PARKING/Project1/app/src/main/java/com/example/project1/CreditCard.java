package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class CreditCard extends AppCompatActivity {
    Button btn;

    EditText amt;
    Button pay;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_credit_card);
        btn = findViewById(R.id.upi);
        amt = findViewById(R.id.editcamount);
        pay = findViewById(R.id.pay);


        pay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                int curr_amount = Integer.parseInt(amt.getText().toString());
                SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sh.edit();
                int temp = sh.getInt("amount", 0);
                myEdit.putInt("amount", (temp + curr_amount));
                myEdit.apply();
                Intent intent = new Intent(getApplicationContext(), wallet.class);
                startActivity(intent);
            }
        });


        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i = new Intent(getApplicationContext(),UPI.class);
                startActivity(i);
            }
        });
    }
}