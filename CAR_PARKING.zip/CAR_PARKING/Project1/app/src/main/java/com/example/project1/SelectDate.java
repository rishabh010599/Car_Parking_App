package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.WindowDecorActionBar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.TimePicker;
import android.widget.Toast;

public class SelectDate extends AppCompatActivity {

    Button btn;
    DatePicker d;
    TimePicker t1, t2;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_select_date);

        btn = findViewById(R.id.slot_button);
        d=  findViewById(R.id.datePicker);
        t1 = findViewById(R.id.timePicker2);
        t2 = findViewById(R.id.timePicker3);

        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String date = d.getDayOfMonth() + "-" + d.getMonth() + "-" + d.getYear();
                String from = "" + t1.getCurrentHour() + t1.getCurrentMinute();
                String to = "" + t2.getCurrentHour() + t2.getCurrentMinute();
                int fromInt = t1.getCurrentHour();
                int toInt = t2.getCurrentHour();

                Intent i = new Intent(getApplicationContext(), BookSlots.class);
                i.putExtra("date", date);
                i.putExtra("from", from);
                i.putExtra("to", to);
                i.putExtra("fromInt", fromInt);
                i.putExtra("toInt", toInt);
                startActivity(i);
            }
        });
    }
}