package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.Spinner;
import android.widget.Toast;


public class Location extends AppCompatActivity {
    private String selectedCity;
    private Spinner citySpinner,areaSpinner;
    private ArrayAdapter<CharSequence>  cityAdapter,areaAdapter;
    String main_city, sub_city;
    Button submit;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_location);

        submit = findViewById(R.id.button_submit);
        areaSpinner = findViewById(R.id.areaSpin);
        citySpinner = (Spinner) findViewById(R.id.spinner_city);
        cityAdapter = ArrayAdapter.createFromResource(this,R.array.array_city,R.layout.spinner_layout);

        cityAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        citySpinner.setAdapter(cityAdapter);

        //when any item on city spinner is selected
        citySpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                areaSpinner = findViewById(R.id.areaSpin);
                //obtain the selected city
                selectedCity = citySpinner.getSelectedItem().toString();
                int parentId = adapterView.getId();
                main_city = selectedCity;

                if(parentId == R.id.spinner_city){


                    switch(selectedCity) {
                        case "Select City":

                            areaAdapter = ArrayAdapter.createFromResource(adapterView.getContext(), R.array.arr_def_area, R.layout.spinner_layout);
                            break;

                        case "Udupi":
                            areaAdapter = ArrayAdapter.createFromResource(adapterView.getContext(),R.array.array_udupi,R.layout.spinner_layout);
                            break;

                        case "Mangalore": areaAdapter = ArrayAdapter.createFromResource(adapterView.getContext(),R.array.array_mangalore,R.layout.spinner_layout);
                            break;

                        case "Bangalore": areaAdapter = ArrayAdapter.createFromResource(adapterView.getContext(),R.array.array_bangalore,R.layout.spinner_layout);
                            break;

                        case "Mysore": areaAdapter = ArrayAdapter.createFromResource(adapterView.getContext(),R.array.array_Mysore,R.layout.spinner_layout);
                            break;
                        default:break;
                    }
                    areaAdapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                    areaSpinner.setAdapter(areaAdapter);
                }
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });

        areaSpinner.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
            @Override
            public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
                sub_city = areaSpinner.getSelectedItem().toString();
            }

            @Override
            public void onNothingSelected(AdapterView<?> adapterView) {

            }
        });


        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
                SharedPreferences.Editor myEdit = sh.edit();
                myEdit.putString("main", selectedCity);
                myEdit.putString("sub", sub_city);
                myEdit.apply();

                Intent intent = new Intent(getApplicationContext(), SelectDate.class);
                startActivity(intent);
            }
        });

    }
}