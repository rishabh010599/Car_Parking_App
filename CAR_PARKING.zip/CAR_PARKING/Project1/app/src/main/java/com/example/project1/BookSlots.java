package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;

public class BookSlots extends AppCompatActivity {
    TextView tv;
   boolean[] SlotState= {false,true,true,true,false,true,true,true,true,true};
   HashMap<Integer, Integer> map = new HashMap<>();
   ArrayList<Button> list = new ArrayList<>();
    ArrayList<Integer> slots;
   Button b1, b2, b3, b4, b5, b6, b7, b8, b9, b10, submit;
   String _date = "";
   String _from = "";
   String _to = "";
   int frm = 0;
   int t = 0;
   String date;
   int slot = 0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book_slots);
        tv = findViewById(R.id.output);

        map.put(0, 20);
        map.put(1, 50);
        map.put(2, 100);
        map.put(3, 150);

        b1 = findViewById(R.id.button4);
        b2 = findViewById(R.id.button10);
        b3 = findViewById(R.id.button7);
        b4 = findViewById(R.id.button11);
        b5 = findViewById(R.id.button9);
        b6 = findViewById(R.id.button12);
        b7 = findViewById(R.id.button14);
        b8 = findViewById(R.id.button15);
        b9 = findViewById(R.id.button16);
        b10 = findViewById(R.id.button17);
        
        submit = findViewById(R.id.btn);

        list.add(b1); list.add(b2);
        list.add(b3); list.add(b4);
        list.add(b5); list.add(b6);
        list.add(b7); list.add(b8);
        list.add(b9); list.add(b10);

        SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
        String _email = sh.getString("email", "");
        String _main = sh.getString("main", "");
        String _sub = sh.getString("sub", "");
        

        Intent intent = getIntent();

        _date = intent.getStringExtra("date");
        frm = intent.getIntExtra("fromInt", 0);
        t = intent.getIntExtra("toInt", 0);

        _from = intent.getStringExtra("from");
        _to = intent.getStringExtra("to");


        DBHelper helper = new DBHelper(getApplicationContext());
        slots = helper.checkSlot(_main, _sub, _date, frm, t);

        Toast.makeText(this, "" + slots.toString(), Toast.LENGTH_SHORT).show();

        for(int i = 0; i < 10; i++){
            if(slots.contains(i + 1)){
                SlotState[i] = false;
            }
            else{
                SlotState[i] = true;
            }
        }
        setState();

        submit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
                String _email = sh.getString("email", "");
                String _main = sh.getString("main", "");
                String _sub = sh.getString("sub", "");


                DBHelper helper = new DBHelper(getApplicationContext());
                int dur = t - frm;
                int amt = map.get(dur);

                tv.setText("Price: " + amt);

                int money = sh.getInt("amount", 0);

                if(money > amt){
                    SharedPreferences.Editor myEdit = sh.edit();
                    myEdit.putInt("amount", (money - amt));
                    myEdit.apply();
                    long res = helper.addRecord(_email, _main, _sub, _date, _from, _to, frm, t, slot);
                    Toast.makeText(BookSlots.this, "Paid", Toast.LENGTH_SHORT).show();

                    //write your code here


                }
                else{
                    Toast.makeText(BookSlots.this, "Kaas ijji arre", Toast.LENGTH_SHORT).show();
                }
            }
        });

    }

    public void setState(){
        for(int i = 0; i < 10; i++){
            if(!SlotState[i]){
                list.get(i).setBackground(getResources().getDrawable(R.drawable.greyh_button));
                list.get(i).setClickable(false);
            }
            else{
                list.get(i).setBackground(getResources().getDrawable(R.drawable.green_button));
                list.get(i).setClickable(true);

            }
        }
    }
    public void selectMe(View v){
        Button btn = (Button) v;
        setState();
        btn.setBackground(getResources().getDrawable(R.drawable.red_button));
        for(int i = 0; i < 10; i++){
            if(v.getId() == list.get(i).getId()) {
                slot = i + 1;
                Toast.makeText(this, "" + slot, Toast.LENGTH_SHORT).show();
            }
        }
    }
}