package com.example.project1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.appcompat.app.AppCompatActivity;
import androidx.cardview.widget.CardView;
import androidx.core.view.GravityCompat;
import androidx.drawerlayout.widget.DrawerLayout;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.android.material.navigation.NavigationView;

public class MainActivity extends AppCompatActivity implements NavigationView.OnNavigationItemSelectedListener {

    private DrawerLayout drawerLayout;
    public ActionBarDrawerToggle actionBarDrawerToggle;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
        SharedPreferences.Editor myEdit = sh.edit();

        String email = sh.getString("email", "");
        if(email.equals("")){
            Intent intent = new Intent(getApplicationContext(), login.class);
            startActivity(intent);
        }

        NavigationView navigationView=findViewById(R.id.des_navigation_view);
        navigationView.setNavigationItemSelectedListener(this);

        drawerLayout = findViewById(R.id.my_drawer_layout);
        actionBarDrawerToggle = new ActionBarDrawerToggle(this, drawerLayout, R.string.nav_open, R.string.nav_close);

        drawerLayout.addDrawerListener(actionBarDrawerToggle);
        actionBarDrawerToggle.syncState();

        // to make the Navigation drawer icon always appear on the action bar
        getSupportActionBar().setDisplayHomeAsUpEnabled(true);
    }
    public void wallet(View view){
        Intent i = new Intent(this,wallet.class);
        startActivity(i);
    }

    public void location(View view){
        Intent it = new Intent(this,Location.class);
        startActivity(it);
    }

    @Override
    public boolean onNavigationItemSelected(@NonNull MenuItem item) {
        String str = (String) item.getTitle();

        if(str.equals("EXIT")){
            MainActivity.this.finishAffinity();
            System.exit(0);
            return true;
        }
        if(str.equals("SETTINGS")){
            Intent intent = new Intent(getApplicationContext(),settings.class);
            startActivity(intent);
            return  true;
        }
        if(str.equals("LOG OUT")){

            SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
            SharedPreferences.Editor myEdit = sh.edit();
            myEdit.putString("email", "");
            myEdit.apply();

            Intent intent = new Intent(getApplicationContext(), login.class);
            startActivity(intent);
        }

        drawerLayout.closeDrawer(GravityCompat.START);
        return true;
    }
    @Override
    public boolean onOptionsItemSelected(@NonNull MenuItem item) {

        if (actionBarDrawerToggle.onOptionsItemSelected(item)) {
            return true;
        }
        return super.onOptionsItemSelected(item);
    }
    @Override
    public void onBackPressed() {
        if (drawerLayout.isDrawerOpen(GravityCompat.START)) {
            drawerLayout.closeDrawer(GravityCompat.START);
        } else {
            super.onBackPressed();
        }
    }
}

