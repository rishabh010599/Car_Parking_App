package com.example.project1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;

public class DBHelper extends SQLiteOpenHelper{
    public static final String DBNAME = "user.db";

    public DBHelper(Context context) {
        super(context,"user.db", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase mydb) {
        mydb.execSQL("create table user(name TEXT,email TEXT,password TEXT,phone NUMBER)");
        mydb.execSQL("create table slot(email TEXT, main TEXT, sub TEXT, currDate TEXT, fromStr TEXT, toStr TEXT, fromTime NUMBER, toTime NUMBER, slotNo NUMBER)");

    }
    @Override
    public void onUpgrade(SQLiteDatabase mydb, int i, int i1) {
        mydb.execSQL("drop Table if exists email");

    }

    public Boolean insertData(String name, String email,String password,String phone)
    {
        SQLiteDatabase mydb = this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("name",name);
        contentValues.put("email",email);
        contentValues.put("password",password);
        contentValues.put("phone",phone);
        long result = mydb.insert("user",null,contentValues);
        if(result == -1)
            return false;
        else
            return true;
    }
    public Boolean checkusername(String email){
        SQLiteDatabase mydb = this.getWritableDatabase();
        Cursor cursor = mydb.rawQuery("select * from user where email=?",new String[] {email});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }
    public Boolean checkusernamepassword(String email,String password)
    {
        SQLiteDatabase mydb=this.getWritableDatabase();
        Cursor cursor = mydb.rawQuery("select * from user where email=? and password=?",new String[] {email,password});
        if(cursor.getCount()>0)
            return true;
        else
            return false;
    }

    public long updateProfile(String a, String b, String c, String d) {
        long res = 0;

        SQLiteDatabase db = getWritableDatabase();
        ContentValues values = new ContentValues();
        values.put("name", b);
        values.put("email", c);
        values.put("phone", d);

        String whereClause = "email=?";
        String whereArgs[] = {a};
        res = db.update("user", values, whereClause, whereArgs);

        return res;
    }

    public ArrayList<String> getProfile(String email){
        ArrayList<String> arr = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String str = "select * from user where email = '"+email+"'";
        Cursor cursor = db.rawQuery(str, null);
        if(cursor.moveToFirst()){
            do{
                arr.add(cursor.getString(0));
                arr.add(cursor.getString(1));
                arr.add(cursor.getInt(2) + "");

            }while (cursor.moveToNext());
        }

        return arr;
    }

    public boolean checkPassword(String email, String s1){
        SQLiteDatabase db = getReadableDatabase();
        String str = "select * from user where email = '"+email+"' AND password = '"+s1+"'";
        Cursor c = db.rawQuery(str, null);

        if(c.getCount() == 0)
            return false;

        return true;
    }

    public void updatePassword(String email, String s3){
        SQLiteDatabase db = getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("password", s3);

        String whereClause = "email=?";
        String whereArgs[] = {email};
        db.update("user", values, whereClause, whereArgs);

    }

    public ArrayList<Integer> checkSlot(String main, String sub, String date, int fromTime, int toTime){
        ArrayList<Integer> slots = new ArrayList<>();
        SQLiteDatabase db = getReadableDatabase();
        String str = "select * from slot where main = '"+main+"' AND sub = '"+sub+"' AND currDate = '"+date+"' AND toTime >= '"+fromTime+"'";
        Cursor cursor = db.rawQuery(str, null);
        if(cursor.moveToFirst()){
            do{
                slots.add(cursor.getInt(8));
            }while (cursor.moveToNext());
        }

        return slots;
    }

    public long addRecord(String email, String main, String sub, String date, String fS, String tS, int frm, int to, int slt){
        SQLiteDatabase mydb = this.getWritableDatabase();
        ContentValues contentValues=new ContentValues();
        contentValues.put("email",email);
        contentValues.put("main",main);
        contentValues.put("sub",sub);

        contentValues.put("currDate",date);
        contentValues.put("fromStr",fS);
        contentValues.put("toStr",tS);
        contentValues.put("fromTime",frm);
        contentValues.put("toTime",to);
        contentValues.put("slotNo",slt);
        long result = mydb.insert("slot",null,contentValues);

        return result;
    }




}
