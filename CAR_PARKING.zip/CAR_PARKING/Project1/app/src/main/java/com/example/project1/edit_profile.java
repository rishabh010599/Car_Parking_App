package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;

import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.util.ArrayList;

public class edit_profile extends AppCompatActivity {

    EditText name, email, phone;
    Button save;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_edit_profile);

        name = findViewById(R.id.editTextTextPersonName2);
        email = findViewById(R.id.editTextTextPersonName3);
        phone = findViewById(R.id.editTextTextPersonName4);

        SharedPreferences sh = getSharedPreferences("store", MODE_PRIVATE);
        String myemail = sh.getString("email", "");

        DBHelper db = new DBHelper(getApplicationContext());
        ArrayList<String> arr = new ArrayList<>();
        arr = db.getProfile(myemail);

        name.setText(arr.get(0));
        email.setText(arr.get(1));
        phone.setText(arr.get(2));


        save = findViewById(R.id.button);

        save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String _name = name.getText().toString();
                String _email = email.getText().toString();
                String _phone = phone.getText().toString();

                DBHelper helper = new DBHelper(getApplicationContext());
                long res = helper.updateProfile(myemail, _name, _email, _phone);

                SharedPreferences.Editor myEdit = sh.edit();

                myEdit.putString("email", _email);
                myEdit.apply();

            }
        });

    }
}